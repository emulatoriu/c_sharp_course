﻿namespace Monopoly
{
    public class Monopoly
    {        
        public static void Main(string[] arguments)
        {
            // init game
            Spielplan.initFelder();
            Spielplan.initSpieler();
            Spielplan.initDices();
            Spielplan.starteSpiel();

        }
    }
}

# Seven-Segment-and-Sixteen-Segment-Controls-for-WPF
The source code for the article https://www.codeproject.com/Articles/1277331/Seven-Segment-and-Sixteen-Segment-Controls-for-WPF

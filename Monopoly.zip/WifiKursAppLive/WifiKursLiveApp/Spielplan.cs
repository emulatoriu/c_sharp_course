﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GameDice;

namespace Monopoly
{
    class Spielplan
    {
        // initialisiere Spiel
        public const int startBetrag = 200;
        public const int iLosMoney = 5;
        //public const int losGeld = 5;
        //public const int genauAufLosMultiplikator = 2;

        private static int iWuerfelRunden = 0; // zählt die Anzahl der Runden für die Statistik
        private static int anzahlZuege = 0; // zählt die Anzahl an Zügen für die Statistik

        private const int ID_LOS = 1;
        private const int ID_FIRST_PLAYER = 0;
        private const int MAX_PLAYERS = 8;

        private const string EXIT_OPTION = "Exit99";

        private static readonly string[] STANDARD_NAME_LIST = new string[MAX_PLAYERS]; // config File und readonly

        private static int idCounter;

        static int limitPlayerPos = 0;

        static Spieler sMatthias;
        static Spieler sYa_Sin;
        static Spieler sThomas;
        static Spieler sJakob;
        static Spieler sDanielT;
        static Spieler sDanielR;
        static Spieler sEmad;

        static Bank bank;

        static Feld fLos;
        static Feld fFeld2;
        static Feld fFeld3;
        static Feld fFeld4;
        static Feld fFeld5;

        //static Spieler[] meinSpielerArray;
        static List<Spieler> meinSpielerArray;

        static DiceThrow dt;

        static Spielplan()
        {
            STANDARD_NAME_LIST[0] = "Matthias";
            STANDARD_NAME_LIST[1] = "Ya Sin";
            STANDARD_NAME_LIST[2] = "DanielT";
            STANDARD_NAME_LIST[3] = "DanielR";
            STANDARD_NAME_LIST[4] = "Thomas";
            STANDARD_NAME_LIST[5] = "Jakob";
            STANDARD_NAME_LIST[6] = "Emad";
            STANDARD_NAME_LIST[7] = "Meister Joda";            
        }

        public static void erhoeheZuege()
        {
            anzahlZuege++;
        }

        // gib zurück wie oft gewürfelt wurde
        public static int getAnzahlZuege()
        {
            return anzahlZuege;
        }

        // wie viele würfelrunden hat es gegeben
        public static void erhoeheRunde()
        {
            iWuerfelRunden++;
        }

        public static int wieVieleRunden()
        {
            return iWuerfelRunden;
        }

        public static void initDices()
        {
            dt = new DiceThrow(2, 6);
        }

        #region init
        public static void initSpieler()
        {            
            meinSpielerArray = new List<Spieler>();
            int iSpielerID = ID_FIRST_PLAYER;            

            // User interaction
            Console.WriteLine("Wieviele Spieler sollen an dem Spiel teilnehmen?");

            string sAnzahlDerSpieler = Console.ReadLine();
            int iAnzahlDerSpieler = 0;
            bool wurdeZahlEingegeben = false;

            // So lange nicht zwischen 2-8 Spieler angegeben wurde
            while (wurdeZahlEingegeben == false || iAnzahlDerSpieler > MAX_PLAYERS || iAnzahlDerSpieler < 2)
            {                
                wurdeZahlEingegeben = int.TryParse(sAnzahlDerSpieler, out iAnzahlDerSpieler);
                if (!wurdeZahlEingegeben || iAnzahlDerSpieler > MAX_PLAYERS || iAnzahlDerSpieler < 2)
                {
                    // User interaction
                    Console.WriteLine("Bitte nur Zahlen von 2-8 eingeben");
                    sAnzahlDerSpieler = Console.ReadLine();
                }
            }

            // User interaction
            Console.WriteLine("Wollen Sie die Namen der Mitspieler manuell eingeben?");

            List<string> jaNeinMenu = new List<string>() {"ja", "nein"};

            int selectedIndex = printMenu(jaNeinMenu); // wenn 0, dann ja sonst nein

            //TODO: Kommentiere von hier an
            if(selectedIndex == 0)
            {
                string name = "";
                for(int i=0; i < iAnzahlDerSpieler; i++)
                {
                    Console.WriteLine($"Bitte gib den {i + 1}. Namen an:");
                    name = Console.ReadLine();
                    meinSpielerArray.Add(new Spieler(ref iSpielerID, name, startBetrag, fLos));
                    Console.WriteLine();
                }
            }
            else if(selectedIndex == 1)
            {
                for(int i=0; i< iAnzahlDerSpieler; i++)
                {
                    //Spieler spieler = new Spieler(ref iSpielerID, sTempSpielerName + i, startBetrag);
                    //spieler.setSpielerFeld(fLos);
                    meinSpielerArray.Add(new Spieler(ref iSpielerID, STANDARD_NAME_LIST[i], startBetrag, fLos));
                }
            }
            else // should not be reached
            {
                //TODO: Create own exception
                throw new Exception("Falscher Menüpunkt: Fehler 0x00bbheodfhjuhahahahahahha bitte rufen Sie 012345678 an.");
            }

            limitPlayerPos = meinSpielerArray.Count;           

            bank = new Bank(5000);

        }

        public static void initFelder()
        {
            idCounter = ID_LOS;
            fLos = new Feld(0, 0, ref idCounter);
            fLos.setKaufenMoeglich(false);
            fFeld2 = new Feld(40, 10, ref idCounter);
            fFeld3 = new Feld(60, 50, ref idCounter);
            fFeld4 = new Feld(80, 20, ref idCounter);
            fFeld5 = new Feld(100, 25, ref idCounter);

            /*
             * Damit Spieler von einem Feld zum nächsten kommen, wird in jedem Feld
             * das Folgefeld gesetzt.
             */
            fLos.setNextFeld(fFeld2);
            fFeld2.setNextFeld(fFeld3);
            fFeld3.setNextFeld(fFeld4);
            fFeld4.setNextFeld(fFeld5);
            fFeld5.setNextFeld(fLos);            

            //TODO GEFÄNGNISFELD

        }
        #endregion

        private static void playerExit(Spieler spieler, Spieler besitzer)
        {            
            spieler.payToAccount(besitzer, spieler.getBalance());            
            playerExit(spieler);

        }

        private static void playerExit(Spieler spieler)
        {
            spieler.setPlayerActive(false);
            Console.WriteLine(spieler.getName() + ", du bist leider raus!");
            Console.WriteLine("Hier ist deine Spielstatistik: ");
            spieler.showSpielerStatistik();
            //TODO: spieler.releaseProperty() and money if he has;
        }

        

        #region doPlayerMove

        private static void doPlayerMove(Spieler spieler, int wuerfelErgebnis, ref int aktuellerUser)
        {

            //if (spieler.getIsActive() == false)
            //{
            //    aktuellerUser++;
            //}
            //else // Ziehe Felder
            if(spieler.getIsActive())
            {                
                spieler.addFeldCount(wuerfelErgebnis);
                for (int i = 0; i < wuerfelErgebnis; i++)
                {
                    // Setze das Spieler Feld auf das nächste Feld vom aktuellen aus
                    //  = Bring den Spieler zum nächsten Feld
                    spieler.setSpielerFeld(spieler.getCurrentFeld().getNext());                    
                    if (spieler.getCurrentFeld().getFeldNummer() == Spielplan.ID_LOS)
                    {
                        spieler.increaseLosCounter();                        
                        if (i == wuerfelErgebnis - 1)
                        {
                            //spieler.getAndMakePayment(losGeld * genauAufLosMultiplikator);
                            int iLosMoneyPaid = bank.payLosMoney(spieler, true);
                            Console.WriteLine("Hey, du bist genau auf Los gekommen und erhälst " + iLosMoneyPaid + " Euro.");
                        }
                        else
                        {
                            int iLosMoneyPaid = bank.payLosMoney(spieler, false);
                            Console.WriteLine("Hey, du bist über Los gekommen und erhälst " + iLosMoneyPaid + " Euro.");
                        }
                    }


                }

                Console.WriteLine(spieler.getName() + " ist jetzt dran und muss " + wuerfelErgebnis + " Felder ziehen. " + aktuellerUser);
                Console.WriteLine(spieler.getName() + " steht jetzt auf Feld " + spieler.getCurrentFeld().getFeldNummer());
                Console.WriteLine();
                spieler.getCurrentFeld().printFeldInfo();
                Console.WriteLine();
                Console.WriteLine(spieler.getName() + ", dein Guthaben beträgt " + spieler.getBalance());

                int currentMoney = spieler.getBalance();

                if (spieler.getCurrentFeld().getKaufenMoeglich() == true)
                {
                    // TODO - überprüfe ob das Feld auf dem du gelandet bist einem Spieler gehört, der nicht mehr aktiv ist
                    // wenn ja, dann setz den besitzer des Feldes auf null

                    if (spieler.getCurrentFeld().getBesitzer() == null)
                    { // Feld ist noch zu haben

                        int preisVomFeld = spieler.getCurrentFeld().getPreis();
                        // Überprüfen ob der Spieler das Feld kaufen kann
                        //if (preisVomFeld > spieler.getBalance())
                        if (spieler.isBalanceEnough(preisVomFeld) == false)
                        {
                            Console.WriteLine("Leider übersteigt der Preis des Feldes dein Guthaben von " + spieler.getBalance() + "!");
                        }
                        else
                        {
                            Console.WriteLine(spieler.getName() + ", möchtest du das Feld kaufen?");
                            List<string> jaNeinMenu = new List<string>() { "ja", "nein" };

                            int selectedIndex = printMenu(jaNeinMenu); // wenn 0, dann ja sonst nein


                            if (selectedIndex == 0)
                            {// Spieler will das Feld kaufen

                                // Gib Geld aus und speichere den Spieler im Feld
                                spieler.payToAccount(bank, preisVomFeld);

                                // Setze den Eigentümer auf des aktuellen Feldes auf den Spieler, der auf dem
                                // Feld gelandet ist.
                                spieler.getCurrentFeld().setBesitzer(spieler);

                                Console.WriteLine($"{spieler.getName()}, du hast das Feld für {preisVomFeld} gekauft. Gratulation!");

                            }
                            // Feld ist noch zu haben
                            //Console.WriteLine(spieler.getName() + ", möchtest du das Feld kaufen? Schreib ja oder nein.");
                            //string eingabe = "";

                            //while (eingabe.ToLower().Equals("ja") == false && eingabe.ToLower().Equals("nein") == false)
                            //{
                            //    eingabe = Console.ReadLine();

                            //    if (eingabe.ToLower().Equals("ja") == true)
                            //    {
                            //        // Gib Geld aus und speichere den Spieler im Feld

                            //        //int newCurrentMoney = currentMoney - preisVomFeld;
                            //        //spieler.setCurrentMoney(newCurrentMoney);
                            //        //spieler.modifyMoney(-preisVomFeld); // TODO: Geld muss an die Bank zurück gehen
                            //        //spieler.kaufeGrundstück(preisVomFeld);
                            //        spieler.payToAccount(bank, preisVomFeld);

                            //        spieler.getCurrentFeld().setBesitzer(spieler);
                            //    }
                            //    else if (eingabe.ToLower().Equals("nein") == false)
                            //    {
                            //        Console.WriteLine("Bitte gib nur ja oder nein ein!");

                            //    }
                            //}


                        }
                    }
                    else if(spieler.getId() != spieler.getCurrentFeld().getBesitzer().getId())
                    {// Feld gehört nicht dem Spieler, der auf das Feld gekommen ist                        
                        
                        Spieler besitzer = spieler.getCurrentFeld().getBesitzer();
                        int mietPreis = spieler.getCurrentFeld().getMietPreis();

                        int paidMoney = 0;


                        // Hat der Spieler genug Geld und ist das Feld auf dem er gelandet ist nicht belehnt?
                        if (spieler.isBalanceEnough(mietPreis) == true && spieler.getCurrentFeld().getMortgaged() == false)
                        {// Zahle die Miete
                            // Fall Spieler hat genug Geld und Feld ist nicht belehnt
                            spieler.payToAccount(besitzer, mietPreis);
                            paidMoney = mietPreis;
                        }                        
                        else if(spieler.getCurrentFeld().getMortgaged() == false)
                        {                        
                            // Fall: Spieler hat nicht genug Geld und Feld ist nicht belehnt
                            if(spieler.getHowManyFieldsDoIHave() > 0) // TODO: nicht nur zählen, wie viele Felder ich habe sondern wie viele unbelehnte Felder
                            {
                                //TODO:
                                //Hier müssten wir den spieler fragen, ob er ein Grundstück belehnen möchte
                                // Wenn er nicht belehnen will -> Grundstücke freigeben
                                // spieler.setPlayerActive(false);--> gib seine Statistik aus
                                Console.WriteLine(spieler.getName() + "_" + spieler.getId() + ", möchtest du eine Hypothek aufnehmen?");

                                // TODO: put our menu function here
                                string eingabe = Console.ReadLine();

                                
                                // sag ob du belehnen möchtest
                                while (eingabe.ToLower().Equals("ja") == false && eingabe.ToLower().Equals("nein") == false)
                                {
                                    Console.WriteLine("Bitte gib nur ja oder nein ein!");
                                    eingabe = Console.ReadLine();                                    
                                }


                                if (eingabe.ToLower().Equals("ja") == true)
                                {//belehne ein oder mehrere Felder
                                    while (mietPreis > spieler.getBalance())
                                    {
                                        string myFieldIds = ",";
                                        //1.string myFieldIds = ",1,3,5,";
                                        Feld aktuellesFeld = fLos;
                                        for (int i = ID_LOS; i < idCounter; i++)
                                        {
                                            // aktuellesFeld.getMortgaged() == false muss überprüft werden, weil ein Feld, dass bereits belehnt
                                            // wurde, nicht noch einmal belehnt werden darf.
                                            if (aktuellesFeld.getBesitzer() != null && (aktuellesFeld.getBesitzer().getId() == spieler.getId())
                                                && bank.isBalanceEnough(aktuellesFeld.getMortageAmount()) && aktuellesFeld.getMortgaged() == false)
                                            {
                                                myFieldIds += aktuellesFeld.getFeldNummer() + ",";
                                                aktuellesFeld.printFeldInfo();
                                                Console.WriteLine();
                                                Console.WriteLine("*****************************");
                                                Console.WriteLine();
                                                // 1 + Statistik
                                                // 3
                                                // 5
                                                // welche möchtest du?
                                            }
                                            aktuellesFeld = aktuellesFeld.getNext();
                                        }
                                        if (myFieldIds.Equals(",")) // gabs Felder, für die ich von der Bank Geld bekomme und die noch nicht belehnt waren?
                                        {
                                            playerExit(spieler, besitzer);
                                            break;
                                        }
                                        else
                                        {
                                            Console.WriteLine("Welches Feld möchtest du belehnen? Bitte gib die Id ein.");
                                            //2.readline("welches feld")
                                            string sGewaehltesFeld = Console.ReadLine();
                                            while (myFieldIds.Contains("," + sGewaehltesFeld + ",") == false)
                                            {
                                                Console.WriteLine("Bitte wähle ein Feld, dass dir gehört.");
                                                sGewaehltesFeld = Console.ReadLine();
                                            }

                                            int iGewaehltesFeld = int.Parse(sGewaehltesFeld);
                                            bank.mortgageField(getFieldWithId(iGewaehltesFeld));

                                            //spieler.payToAccount(besitzer, mietPreis);
                                        }
                                        if(mietPreis > spieler.getBalance())
                                        {
                                            Console.WriteLine(spieler.getName() + ", du hast noch nicht genügend Geld und musst noch ein Feld belehnen");
                                        }

                                    }// end while
                                    
                                    if(spieler.getIsActive() == true)
                                    {//Spieler ist noch nicht rausgeflogen und hat genug Geld durch Belehnungen erhalten
                                        spieler.payToAccount(besitzer, mietPreis);
                                    }
                                }
                                else //if (eingabe.ToLower().Equals("nein") == true)
                                {
                                    playerExit(spieler, besitzer);                                    
                                }
                            } // TODO: Else if - maybe to sell something?
                            else
                            {
                                playerExit(spieler, besitzer);
                                //paidMoney = spieler.getBalance();
                                //spieler.payToAccount(besitzer, spieler.getBalance());                                
                                //spieler.setPlayerActive(false);                                
                            }
                        }
                        else
                        {
                            Console.WriteLine(spieler.getName() + ", du hattest Glück, das Feld auf dem du stehst ist belehnt.");
                        }

                        // is still active?
                        if (spieler.getIsActive() == true)
                        {
                            Console.WriteLine("Der neue Geldstand von " + spieler.getName() + " = " + spieler.getBalance());
                        }
                        else
                        {
                            // TODO: Here I know that player is out - static counter to check if there is more than one player left
                            Console.WriteLine("Spieler " + spieler.getId() + " mit dem Namen " + spieler.getName() + " ist leider raus!");
                        }

                        Console.WriteLine(besitzer.getName() + " hat " + paidMoney + " erhalten. Der neue Geldstand von " + besitzer.getName() + " = " + besitzer.getBalance());
                    }
                }
                else
                {

                }
            }

        }
        #endregion        

        public static void starteSpiel()
        {
            int iMenu = 0;
            string sEingabe = "";
            int wuerfelErgebnis;
            //Random wuerfel = new Random();
            int aktuellerUser = 0;

            // Start the game
            // TODO: Menü anpassen sodass ein Spieler auch Hypotheken zurückzahlen kann und Hypotheken nehmen kann

            List<string> gameMenu = new List<string>() {"Roll Dices", "Player Statistics", "Exit"};
            int index = 0;
            do
            {
                index = printMenu(gameMenu);



                if (index == 0)
                {//Roll Dices
                    List<int> diceResults;
                    diceResults = dt.RollDice();
                    
                    wuerfelErgebnis = diceResults.Sum();
                    // == 
                    //foreach (int d in diceResults)
                    //{
                    //    wuerfelErgebnis += d;
                    //}
                    Spielplan.erhoeheZuege();
                    //Console.WriteLine("***************************************");
                    //Console.WriteLine("***************************************");
                    //Console.WriteLine("***************************************");
                    //Console.WriteLine("MODULO FRIENDS");
                    //Console.WriteLine($"Aktueller user counter {nameof(aktuellerUser)} = {aktuellerUser}");
                    //Console.WriteLine($"Folgender Spieler ist jetzt dran: {aktuellerUser%limitPlayerPos} {meinSpielerArray[aktuellerUser % limitPlayerPos].getName()}");
                    //Console.WriteLine("***************************************");
                    //Console.WriteLine("***************************************");
                    //Console.WriteLine("***************************************");

                    doPlayerMove(meinSpielerArray[aktuellerUser], wuerfelErgebnis, ref aktuellerUser);

                    if (aktuellerUser >= limitPlayerPos - 1)
                    {
                        aktuellerUser = 0;
                        Spielplan.erhoeheRunde();
                    }
                    else
                    {
                        aktuellerUser++;
                    }

                    //if(getPlayerCount() <= 1 == true)
                    //{
                    //    //mach Ausgabe und return;
                    //}

                }
                else if (index == 1)
                {
                    // TODO: Menu für Spielerstatistik
                    showSpielStatistik();

                    Console.WriteLine("Gib bitte an, von welchem Spieler du die Statistik sehen möchtest?");
                    String sSpielerId = Console.ReadLine();
                    int iSpielerId = 1;
                    int.TryParse(sSpielerId, out iSpielerId);



                    foreach (Spieler spieler in meinSpielerArray)
                    {
                        if (spieler.getId() == iSpielerId)
                        {
                            spieler.showSpielerStatistik();
                            break;
                        }
                    }
                    bank.showStatistics();

                }
            }
            while (index != 2);
        }

        /// <summary>
        /// Die Funktion baut ein Menü in der Konsole auf, dass aus den Elementen der Liste
        /// besteht. Jeder Menüpunkt ist durch einen Pfeil selektierbar.
        /// </summary>
        /// <param name="menuList">Enthält die Menüpunkte für die Navigation</param>
        /// <returns>Returniert die Position des selektierten Menüpunktes, beginnend mit 0</returns>
        public static int printMenu(List<string> menuList) // TODO: add to GameLib.dll
        {
            int index = 0;

            WriteMenu(menuList, index);

            // Store key info in here
            ConsoleKeyInfo keyinfo;

            // Erstelle so lange ein interaktives Menü mit durch Pfeiltasten
            // selektierten Index bis die Eingabetaste gedrückt wird
            do
            {
                // Lies von der Tastatur ein
                keyinfo = Console.ReadKey();

                // Handle each key input (down arrow will write the menu again with a different selected item)
                if (keyinfo.Key == ConsoleKey.DownArrow)
                {
                    // Überprüfe die Indexnummer der nächsten Zeile.
                    // Verlasse ich meinen selektierbaren Bereich?
                    if (index + 1 < menuList.Count)
                    {//nein
                        index++;
                        // lösche mein Menü
                        ClearOptions(menuList.Count);
                        // bau mein Menü wieder auf
                        WriteMenu(menuList, index);
                    }
                }
                else if (keyinfo.Key == ConsoleKey.UpArrow)
                {
                    // Überprüfe die Indexnummer der vorigen Zeile.
                    // Verlasse ich meinen selektierbaren Bereich?
                    if (index - 1 >= 0)
                    {//nein
                        index--;
                        ClearOptions(menuList.Count);
                        WriteMenu(menuList, index);
                    }
                }
                // Handle different action for the option
                else if (keyinfo.Key == ConsoleKey.Enter)
                {
                    foreach (string item in menuList)
                    {
                        Console.WriteLine(); // TODO: write line mit "" falls es nicht funktioniert                    
                    }                    

                }
                else if (keyinfo.Key != ConsoleKey.Enter)
                {
                    Console.Write("\b \b"); // Clear last char
                }
            }
            //while (keyinfo.Key != ConsoleKey.X);
            while (keyinfo.Key != ConsoleKey.Enter);
            
            return index;
        }

        // FÜr die Statistik werden alle aktiven Spieler ausgegeben
        public static void showActivePlayers()
        {

            //Spieler firstPlayerToCheck = sMatthias;//getSpielerWithId(0);
            //Spieler player = sMatthias;
            foreach (Spieler spieler in meinSpielerArray)
            {
                if (spieler.getIsActive() == true)
                {
                    Console.WriteLine(spieler.getName() + " ist noch im Spiel!");
                }
                else
                {
                    Console.WriteLine(spieler.getName() + " ist nicht mehr im Spiel!");
                }
            }
            //do
            //{
            //    //Spieler nextPlayer = sMatthias.getNextSpieler();
            //    if (player.getIsActive() == true)
            //    {
            //        Console.WriteLine(player.getName() + " ist noch im Spiel!");
            //    }
            //    //else
            //    //{
            //    //    Console.WriteLine(player.getName() + " ist nicht mehr im Spiel!");
            //    //}
            //    player = player.getNextSpieler();
            //}
            //while (sMatthias.getId() != player.getId());
        }

        public static Feld getFieldWithId(int iGewaehltesFeld)
        {
            Feld startFeld = fLos;

            for (int i = ID_LOS; i < idCounter; i++) // TODO: Test if output is correct
            {
                //Spieler nextPlayer = sMatthias.getNextSpieler();
                if (startFeld.getFeldNummer() == iGewaehltesFeld)
                {
                    return startFeld;
                }
                startFeld = startFeld.getNext();
            }

            return null; // can not reach here
        }

        public static void showBuyableFields()
        {
            Feld startFeld = fLos;

            for(int i = ID_LOS; i < idCounter; i++) // TODO: Test if output is correct
            {
                //Spieler nextPlayer = sMatthias.getNextSpieler();
                if (startFeld.darfIchDasFeldKaufen())
                {
                    Console.WriteLine(startFeld.getFeldNummer() + " ist noch zu haben!");                    
                }
                startFeld = startFeld.getNext();
            }            
        }

        public static Spieler getLastSpieler()
        {
            return null;
        }

        public static void showSpielStatistik()
        {

            //1.Welche Spieler sind noch dabei
            showActivePlayers();
            //2. Anzahl der Spielzüge            
            Console.WriteLine("Anzahl der Züge: " + getAnzahlZuege());
            ////9. Wie oft hat ein Spieler gewürfelt - iteriere über jeden SPieler und addiere
            //Console.WriteLine("Gesamte Würfe im Spiel: " + getAnzahlZuege());
            //(11. Wie lange läuft das Spiel schon)
            //12. Welche Felder sind noch frei
            showBuyableFields();
            //13. Wie oft wurde über Los gegangen - iteriere über jeden SPieler und addiere



            //WÜRFELKLASSE!
            //14. Welcher Würfel ist am öftesten gefallen? - Eigene Würfelstatistik?
            //10. Wie groß war der Durschnittsweg pro Wurf = Was war die Durschnitts Augenzahl die gewürfet wurde

            //
            //iWuerfelRunden
            //anzahlZuege

        }

        /// <summary>
        /// Die Funktion baut das Menü durch die Elemente in menuList auf
        /// </summary>
        /// <param name="menuList">Enthält die Menüpunkte</param>
        /// <param name="index">Gibt die selektierte Position im Menü an</param>
        static void WriteMenu(List<string> menuList, int index)
        {        
            //TODO: Tipps von Daniel holen
            for(int i=0; i<menuList.Count; i++)
            {
                // Baut den Pfeil und die Farbsettings auf dem Menüpunkt mit dem selektierten Index auf
                if(i==index)
                {
                    Console.ForegroundColor = ConsoleColor.White;
                    Console.BackgroundColor = ConsoleColor.Blue;
                    Console.Write(">");
                }
                else
                {
                                        
                    Console.Write(" ");
                }

                Console.ResetColor();
                Console.WriteLine(menuList[i]);
            }
        }
        //TODO: function that evaluates that the game finished and a function that ends the game and shows the statistics

        /// <summary>
        /// Die Funktion setzt den Cursor zum Beginn unseres Menüs
        /// </summary>
        /// <param name="amountLines">Bestimmt in welcher Zeile das Menü beginnt</param>
        static void ClearOptions(int amountLines)
        {            
            Console.SetCursorPosition(0, Console.CursorTop - amountLines);
        }

    }

}

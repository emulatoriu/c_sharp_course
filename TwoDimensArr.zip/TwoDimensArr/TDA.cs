﻿class TDA
{
    public static void Main(string[] args)
    {
        int[,] einmalEins= new int[11,11];
        for (int i = 0; i < einmalEins.GetLength(0); i++)
        {
            for (int j = 0; j < einmalEins.GetLength(1); j++)
            {
                einmalEins[i, j] = i * j;
            }
        }

        int dimensionCount = einmalEins.Rank;
        for(int i=0; i<dimensionCount; i++)
        {
            Console.WriteLine("Das array " + nameof(einmalEins) + " hat in der Dimension " + i + " " + einmalEins.GetLength(i) + " Werte");
        }

        //einmalEins[5, 5] = 111111;        

        Console.Write("  |");
        for (int i = 0; i < einmalEins.GetLength(0); i++)
        {
            Console.Write(i + "  ");
        }
        Console.WriteLine();
        Console.WriteLine("------------------------------------------------------");

        for (int i=0; i < einmalEins.GetLength(0); i++)
        {
            if (i < 10)
            {
                Console.Write(i + " |");
            }
            else
            {
                Console.Write(i + "|");
            }
            for (int j = 0; j < einmalEins.GetLength(1); j++)
            {
                Console.Write(einmalEins[i, j] + "  ");
            }
            Console.WriteLine();
        }

        


    }
}